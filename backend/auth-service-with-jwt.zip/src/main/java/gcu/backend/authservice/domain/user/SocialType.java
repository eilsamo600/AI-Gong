package gcu.backend.authservice.domain.user;

public enum SocialType {
    KAKAO, NAVER, GOOGLE
}